#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
using namespace std;

int main() {

string alo = "";
char a = 'c';
int p;
int valor = 1;

for(p=5; p <= 10; p++){

cout<< "Bienvenido"<<endl;


}


if(p == 5){
cout<< "Contratado"<<endl;

}else{
cout<< "Despedido"<<endl;
}


while(valor <= 4){
cout<< "Ciclo while" <<endl;
valor++;
}

switch (p){

case 5:

cout<< "Funciona "<<endl;

break;


default:

cout<< "soy una funcion "<<endl;


}

}
