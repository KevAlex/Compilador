/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzer;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author estudiantes
 */
public class AnalizadorLexico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception{
        // TODO code application logic here
        
        //String path =  "C:/Users/estudiantes/Documents/NetBeansProjects/AnalizadorLexico/src/Analyzer/Lexico.flex";
       String path= "../AnalizadorLexico\\src\\Analyzer/Lexico.flex";
        //String path = "C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/Lexico.flex";
        String pat= "../AnalizadorLexico\\src\\Analyzer/LexicoCup.flex";
        //String pat = "C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/LexicoCup.flex";
        String[] pathS= {"-parser","Sintaxis", "../AnalizadorLexico\\src\\Analyzer/Sintaxis.cup"
        };
        
       // String[] pathS = {"-parser","Sintaxis", "C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/Sintaxis.cup"};
        //generateLex(path);
        generateLex(path,pat,pathS); //hinzufügen an generateLex    
        
        
        Formulario prueba = new Formulario();
        prueba.setVisible(true);
        prueba.setLocationRelativeTo(null);
        prueba.setDefaultCloseOperation(prueba.EXIT_ON_CLOSE);
        
    }
    
    public static void generateLex(String path, String pat, String[] pathS)throws IOException, Exception{
        File arc = new File (path);
        JFlex.Main.generate(arc);
        arc = new File(pat);
        JFlex.Main.generate(arc);
        java_cup.Main.main(pathS);
        
        Path caminoSym= Paths.get("../AnalizadorLexico\\src\\Analyzer/sym.java");
        //Path caminoSym= Paths.get("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/sym.java");
        
        if(Files.exists(caminoSym)){
            Files.delete(caminoSym);
        }
        Files.move(
        Paths.get("../AnalizadorLexico\\sym.java"),
          //Paths.get("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\sym.java"),      
          Paths.get("../AnalizadorLexico\\src\\Analyzer/sym.java")        
           );
        //Paths.get("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/sym.java"));
        Path caminoSint= Paths.get("../AnalizadorLexico\\src\\Analyzer/Sintaxis.java");
        //Path caminoSint = Paths.get ("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/Sintaxis.java");
        if (Files.exists(caminoSint)) {
            Files.delete(caminoSint);
        }
        Files.move(
        Paths.get("../AnalizadorLexico\\Sintaxis.java"),
          //Paths.get("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\AnalyzerSintaxis.java"),      
        Paths.get("../AnalizadorLexico\\src\\Analyzer/Sintaxis.java") 
          //Paths.get("C:\\Users\\estudiantes\\Music\\AnalizadorLexico\\src\\Analyzer/Sintaxis.java")   
        );
           
    }
}
